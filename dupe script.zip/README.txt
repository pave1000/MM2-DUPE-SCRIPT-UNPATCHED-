Hello, Thank you for using kunhitor mm2 dupe script.

Before using make sure ur anti-virus is off or else kunhitor wont work.

Before opening kunhitor.exe make sure your in mm2.

This is not bannable.

If you want to report a bug or need help with kunhitor join our discord server: discord.gg/pave

Enjoy our script!




----------------------
Made By pave#1000 ----
----------------------